# Ismael Omar — Portfolio Website

A responsive dark portfolio website built with React + Vite, ready for Vercel.

## Requirements
- Node.js 18 or newer
- npm
- A GitHub account (for the easiest Vercel deployment)

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Build
```bash
npm run build
npm run preview
```

## Deploy to Vercel
1. Create a GitHub repository and upload this project.
2. Sign in at https://vercel.com and choose **Add New → Project**.
3. Import the GitHub repository.
4. Vercel should detect Vite automatically. Confirm:
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
5. Click **Deploy**.

The included `vercel.json` provides a fallback rewrite for client-side routes.

## Personalize before publishing
In `src/App.jsx`:
- Replace `hello@example.com` with your real public contact email.
- Replace GitHub and LinkedIn profile URLs with your own profiles.
- Edit project descriptions to reflect completed work accurately.

This starter uses project concepts as portfolio examples. Update them to match what you have actually built before presenting them as completed client work.
