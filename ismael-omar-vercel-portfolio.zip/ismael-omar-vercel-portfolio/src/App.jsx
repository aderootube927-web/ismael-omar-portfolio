import { useState } from 'react'
import {
  ArrowUpRight, Github, Linkedin, Mail, Menu, X, Code2, BrainCircuit,
  Smartphone, Globe2, Terminal, Sparkles, ExternalLink, Send, Download,
  ChevronDown
} from 'lucide-react'

const projects = [
  {
    number: '01',
    name: 'Masela Health',
    type: 'Digital Healthcare Platform',
    description: 'A healthcare technology concept focused on connecting patient registration, clinical workflows, laboratory services and reporting in one experience.',
    tags: ['React', 'Healthcare', 'UI/UX'],
    icon: <BrainCircuit size={24} />,
    link: '#contact'
  },
  {
    number: '02',
    name: 'PlayBiz',
    type: 'Learning & Entertainment',
    description: 'A skill-based games platform concept with quizzes, virtual points, leaderboards and an administration dashboard.',
    tags: ['React', 'Node.js', 'PostgreSQL'],
    icon: <Sparkles size={24} />,
    link: '#contact'
  },
  {
    number: '03',
    name: 'Personal Portfolio',
    type: 'Web Development',
    description: 'A responsive portfolio designed to introduce my work, technical interests and selected projects.',
    tags: ['Vite', 'JavaScript', 'CSS'],
    icon: <Globe2 size={24} />,
    link: '#'
  }
]

const skills = [
  { name: 'Frontend Development', detail: 'React · JavaScript · HTML · CSS', icon: <Code2 /> },
  { name: 'AI & Emerging Technology', detail: 'AI tools · Automation · Product thinking', icon: <BrainCircuit /> },
  { name: 'Mobile Experiences', detail: 'Flutter · Responsive interfaces', icon: <Smartphone /> },
  { name: 'Web & Deployment', detail: 'Git · GitHub · Vercel · APIs', icon: <Terminal /> },
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const closeMenu = () => setMenuOpen(false)

  return (
    <div className="site-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="header">
        <a className="brand" href="#home" onClick={closeMenu}><span className="brand-mark">IO</span><span>ISMAEL<span className="brand-dot">.</span></span></a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? 'nav nav-open' : 'nav'}>
          {['Home', 'About', 'Skills', 'Projects', 'Contact'].map(item =>
            <a key={item} href={`#${item.toLowerCase()}`} onClick={closeMenu}>{item}</a>
          )}
          <a className="nav-cta" href="#contact" onClick={closeMenu}>Let's talk <ArrowUpRight size={15} /></a>
        </nav>
      </header>

      <main>
        <section className="hero section" id="home">
          <div className="hero-copy">
            <div className="eyebrow"><span className="status-dot" /> AVAILABLE FOR CREATIVE PROJECTS</div>
            <h1>Building digital<br />ideas into <span className="gradient-text">reality.</span></h1>
            <p className="hero-subtitle">I'm <strong>Ismael Omar</strong> — a Software Developer & AI Engineer passionate about creating useful, elegant and human-centered digital experiences.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#projects">Explore my work <ArrowUpRight size={17} /></a>
              <a className="button button-ghost" href="#contact">Get in touch <Mail size={16} /></a>
            </div>
            <div className="social-row">
              <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub"><Github /></a>
              <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin /></a>
              <a href="mailto:hello@example.com" aria-label="Email"><Mail /></a>
            </div>
          </div>
          <div className="hero-visual">
            <div className="orbit orbit-a" /><div className="orbit orbit-b" />
            <div className="hero-card">
              <div className="card-top"><span>DEVELOPER PROFILE</span><span className="card-live">● ONLINE</span></div>
              <div className="avatar">IO</div>
              <h2>Ismael Omar</h2><p>Software Developer<br />& AI Engineer</p>
              <div className="card-divider" />
              <div className="code-line"><span>const</span> passion = <b>"innovation"</b>;</div>
              <div className="code-line"><span>return</span> <b>build(ideas)</b>;</div>
              <div className="floating-chip chip-code"><Code2 size={16} /> Clean code</div>
              <div className="floating-chip chip-ai"><Sparkles size={16} /> AI curious</div>
            </div>
          </div>
          <a className="scroll-cue" href="#about"><span /> SCROLL TO DISCOVER <ChevronDown size={15} /></a>
        </section>

        <section className="section about-section" id="about">
          <div className="section-kicker">01 / ABOUT ME</div>
          <div className="section-heading-row"><h2>Curious mind.<br /><span className="muted">Purposeful builder.</span></h2><p className="section-intro">I enjoy turning complex problems into clear, practical digital solutions. I’m always learning, experimenting and exploring how software and AI can make everyday work better.</p></div>
          <div className="about-grid">
            <div className="about-note"><Sparkles /><h3>Technology with purpose</h3><p>My focus is on building accessible, reliable and useful products — from web experiences to digital tools that support real-world needs.</p></div>
            <div className="stat-card"><strong>01</strong><span>Keep learning</span><small>Grow through curiosity</small></div>
            <div className="stat-card"><strong>02</strong><span>Build thoughtfully</span><small>People before pixels</small></div>
            <div className="stat-card"><strong>03</strong><span>Think forward</span><small>Explore what’s possible</small></div>
          </div>
        </section>

        <section className="section skills-section" id="skills">
          <div className="section-kicker">02 / WHAT I DO</div>
          <div className="section-heading-row"><h2>Tools for turning<br /><span className="muted">ideas into impact.</span></h2><p className="section-intro">A growing toolkit across software development, modern interfaces and emerging technology.</p></div>
          <div className="skills-grid">{skills.map((skill, i) => <article className="skill-card" key={skill.name}><div className="skill-icon">{skill.icon}</div><span className="skill-index">0{i + 1}</span><h3>{skill.name}</h3><p>{skill.detail}</p></article>)}</div>
        </section>

        <section className="section projects-section" id="projects">
          <div className="section-kicker">03 / SELECTED WORK</div>
          <div className="section-heading-row"><h2>Ideas in<br /><span className="muted">progress.</span></h2><p className="section-intro">A selection of concepts and projects that reflect my interests in technology, problem-solving and digital experiences.</p></div>
          <div className="projects-list">{projects.map(project => <article className="project-card" key={project.number}><div className="project-number">{project.number}</div><div className="project-icon">{project.icon}</div><div className="project-info"><span className="project-type">{project.type}</span><h3>{project.name}</h3><p>{project.description}</p><div className="tags">{project.tags.map(tag => <span key={tag}>{tag}</span>)}</div></div><a className="project-link" href={project.link} aria-label={`View ${project.name}`}><ArrowUpRight /></a></article>)}</div>
        </section>

        <section className="contact-section section" id="contact">
          <div className="section-kicker">04 / CONTACT</div>
          <div className="contact-panel"><div><span className="contact-label">HAVE A PROJECT IN MIND?</span><h2>Let's build<br /><span className="gradient-text">something meaningful.</span></h2><p>Have an idea, collaboration or opportunity? I’d be glad to hear about it.</p><a className="button button-primary" href="mailto:hello@example.com">Send me an email <Send size={16} /></a></div><div className="contact-decoration"><Mail size={100} strokeWidth={0.7} /></div></div>
        </section>
      </main>
      <footer className="footer"><a className="brand" href="#home"><span className="brand-mark">IO</span><span>ISMAEL<span className="brand-dot">.</span></span></a><span>Designed & built with curiosity.</span><span>© {new Date().getFullYear()} Ismael Omar</span></footer>
    </div>
  )
}

export default App
